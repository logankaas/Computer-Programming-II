public class RockPaperScissorsRunner {
    public static void main(String[] args) {
        RockPaperScissorsFrame frame = new RockPaperScissorsFrame();
    }
}
