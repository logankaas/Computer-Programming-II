import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

public class InvoiceGUI extends JFrame implements ActionListener {
    private JTextField titleField, addressField, productField, priceField, quantityField;
    private JButton addLineItemButton, displayButton;
    private JTextArea invoiceTextArea;
    private InvoiceGUI invoice;
    ArrayList <LineItem> displayList = new ArrayList<LineItem>();

    public InvoiceGUI() {
        super("Invoice");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create invoice object
        invoice = this;

        // Create input fields and labels
        titleField = new JTextField(20);
        JLabel titleLabel = new JLabel("TITLE:");
        addressField = new JTextField(20);
        JLabel addressLabel = new JLabel("CUSTOMER ADDRESS:");
        productField = new JTextField(20);
        JLabel productLabel = new JLabel("PRODUCT:");
        priceField = new JTextField(5);
        JLabel priceLabel = new JLabel("UNIT PRICE:");
        quantityField = new JTextField(5);
        JLabel quantityLabel = new JLabel("QUANTITY:");

        // Create buttons
        addLineItemButton = new JButton("ADD LINE ITEM");
        addLineItemButton.addActionListener(this);
        displayButton = new JButton("DISPLAY INVOICE");
        displayButton.addActionListener(this);

        // Create invoice text area
        //invoiceTextArea = new JTextArea(20, 50);
        //JScrollPane scrollPane = new JScrollPane(invoiceTextArea);

        // Create panel for input fields
        JPanel inputPanel = new JPanel(new GridLayout(0, 2));
        inputPanel.add(titleLabel);
        inputPanel.add(titleField);
        inputPanel.add(addressLabel);
        inputPanel.add(addressField);
        inputPanel.add(productLabel);
        inputPanel.add(productField);
        inputPanel.add(priceLabel);
        inputPanel.add(priceField);
        inputPanel.add(quantityLabel);
        inputPanel.add(quantityField);
        inputPanel.add(addLineItemButton);


        //Display Invoice Text Area
        invoiceTextArea = new JTextArea(20, 50);
        JScrollPane scrollPane = new JScrollPane(invoiceTextArea);


        // Create panel for buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(displayButton);


        // Add panels and text area to frame
        Container contentPane = getContentPane();
        contentPane.setLayout(new BorderLayout());
        contentPane.add(inputPanel, BorderLayout.NORTH);
        contentPane.add(scrollPane, BorderLayout.CENTER);
        contentPane.add(buttonPanel, BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public class Product {

        public String productName;
        public double unitPrice;
        public Product (String productName, double unitPrice) {
            this.productName = productName;
            this.unitPrice = unitPrice;
        }

    }

    public class LineItem {

        public Product product;
        public int quantity;

        public LineItem (Product product, int quantity) {
            this.product = product;
            this.quantity = quantity;
        }
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == addLineItemButton) {
            // Create product and line item objects
            String productName = productField.getText();
            double unitPrice = Double.parseDouble(priceField.getText());
            int quantity = Integer.parseInt(quantityField.getText());
            Product product = new Product(productName, unitPrice);
            LineItem item = new LineItem(product, quantity);

            // Add line item to invoice and clear input fields
            invoice.addLineItem(item);
            productField.setText("");
            priceField.setText("");
            quantityField.setText("");
        } else if (e.getSource() == displayButton) {
            // Display invoice in text area
            invoice.setTitle(titleField.getText());
            invoice.setCustomerAddress(addressField.getText());
            //invoiceTextArea.setText(invoice.toString());
            invoiceTextArea.setText("\n" + "=========================================================" + "\n" + "ADDRESS:" + addressField.getText() + "\n" + "=========================================================" + "\n" + "PRODUCT:" + productField.getText() + "\n" + "PRICE:" + priceField.getText() + "\n" + "QUANTITY:" + quantityField.getText());
        }
    }

    private void setCustomerAddress(String text) {

    }

    private void addLineItem(LineItem item) {
        displayList.add(item);
    }

    public static void main(String[] args) {
        InvoiceGUI gui = new InvoiceGUI();
    }
}