import java.util.ArrayList;

public class WorkerTest {
    static public void main(String[] args){
        Worker worker1 = new Worker("1", "Test", "10.00", "", 2003, 10.00);
        Worker worker2 = new Worker("2", "Test", "", "", 2004, 12.00);
        Worker worker3 = new Worker("3", "Test", "", "", 2005, 14.00);

        ArrayList<Worker> workers = new ArrayList<Worker>();
        workers.add(worker1);
        workers.add(worker2);
        workers.add(worker3);

        for (Worker w : workers) {
            System.out.println(w.toString());
        }
    }
}
