import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Random;

public class FortuneTellerFrame extends JFrame {
    private JLabel jLabel;
    private JTextArea fortuneArea;
    private JButton buttonRead;
    private JButton buttonQuit;
    private ArrayList<String> fortunes;
    private int lastFortuneIndex = -1;

    public FortuneTellerFrame() {

        super("FORTUNE TELLER");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 600);
        setResizable(false);
        setLocationRelativeTo(null);

        fortunes = new ArrayList<>();
        fortunes.add("You will find money on the street today.");
        fortunes.add("You will succeed all of your classes this semester.");
        fortunes.add("You will be famous someday.");
        fortunes.add("You will travel to an island soon.");
        fortunes.add("You will live a healthy and happy life.");
        fortunes.add("You will be promoted at work.");
        fortunes.add("You will win the lottery.");
        fortunes.add("You will make a great discovery.");
        fortunes.add("You will have a successful career.");
        fortunes.add("You will find true happiness.");
        fortunes.add("You will find your soulmate.");

        // set fortune teller font to arial, set fortune teller font size to 48
        jLabel = new JLabel("FORTUNE TELLER", JLabel.CENTER);
        jLabel.setFont(new Font("Monospaced", Font.BOLD, 48));

        // get image
        ImageIcon fortuneTellerIcon = new ImageIcon("img/fortuneteller.png");

        // resize image to width of 50 and height of 50
        Image fortuneTellerImage = fortuneTellerIcon.getImage();
        Image modifiedFortuneTellerImage = fortuneTellerImage.getScaledInstance(50, 50, Image.SCALE_DEFAULT);
        fortuneTellerIcon = new ImageIcon(modifiedFortuneTellerImage);

        // centering the image
        jLabel.setIcon(fortuneTellerIcon);
        jLabel.setVerticalTextPosition(JLabel.BOTTOM);
        jLabel.setHorizontalTextPosition(JLabel.CENTER);

        // set the text area to arial font and a font size of 24
        fortuneArea = new JTextArea();
        fortuneArea.setEditable(false);
        fortuneArea.setFont(new Font("Arial", Font.PLAIN, 24));

        JScrollPane scrollPane = new JScrollPane(fortuneArea);

        // button to read your fortune and display your fortune
        buttonRead = new JButton("Read My Fortune!");
        buttonRead.setFont(new Font("Serif", Font.BOLD, 24));
        buttonRead.addActionListener((ActionEvent e) -> {
            String fortune = getRandomFortune();
            fortuneArea.append(fortune + "\n");
        });

        // button to quit / end program
        buttonQuit = new JButton("Quit");
        buttonQuit.setFont(new Font("Serif", Font.BOLD, 24));
        buttonQuit.addActionListener((ActionEvent e) -> {
            System.exit(0);
        });

        add(jLabel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(buttonRead);
        buttonPanel.add(buttonQuit);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    // get your randomly displayed fortune
    private String getRandomFortune() {
        int index = lastFortuneIndex;
        while (index == lastFortuneIndex) {
            index = new Random().nextInt(fortunes.size());
        }
        lastFortuneIndex = index;
        return fortunes.get(index);
    }
}
