import java.util.ArrayList;

public class SalaryWorkerTest {
    public static void main(String[] args){
        SalaryWorker salaryWorker1 = new SalaryWorker("1", "Test", "Test","", 2003, 1600.00);
        SalaryWorker salaryWorker2 = new SalaryWorker("2", "Test", "Test", "", 2004, 1800.00);
        SalaryWorker salaryWorker3 = new SalaryWorker("3","Test", "Test", "", 2005, 2000.00);

        ArrayList<SalaryWorker> salaryWorkers = new ArrayList<SalaryWorker>();
        salaryWorkers.add(salaryWorker1);
        salaryWorkers.add(salaryWorker2);
        salaryWorkers.add(salaryWorker3);

        System.out.println("Weekly Pay Per Worker");
        System.out.println("------------------------------------");
        System.out.println("Name\tWeek 1\tWeek 2\tWeek 3");
        System.out.println("------------------------------------");

        for (SalaryWorker sw : salaryWorkers) {
            System.out.println(sw.getName() + "\t" + sw.calculateWeeklyPay(40) + "\t" + sw.calculateWeeklyPay(50) + "\t" + sw.calculateWeeklyPay(40));
        }
    }
}
