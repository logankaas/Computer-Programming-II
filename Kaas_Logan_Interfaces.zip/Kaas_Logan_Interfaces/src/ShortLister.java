import java.awt.*;
import java.util.ArrayList;

public class ShortLister {
    public static ArrayList<Object> collectAll(Filter f, Object[] objects) {
        ArrayList<Object> result = new ArrayList<Object>();
        for (Object obj : objects) {
            if (f.accept(obj)) {
                result.add(obj);
            }
        }
        return result;
    }

    public static void main(String[] args) {
        String[] words = {"hello", "world", "java", "python"};
        ShortWordFilter shortWordFilter = new ShortWordFilter();
        ArrayList<Object> shortWords = collectAll(shortWordFilter, words);
        System.out.println("Short words: " + shortWords);

        Rectangle[] rectangles = {new Rectangle(2, 3), new Rectangle(5, 5), new Rectangle(7, 8), new Rectangle(10, 2)};
        BigRectangleFilter bigRectangleFilter = new BigRectangleFilter();
        ArrayList<Object> bigRectangles = collectAll(bigRectangleFilter, rectangles);
        System.out.println("Big rectangles: " + bigRectangles);
    }

    public static Object[] collectAll(Object[] objects, Filter f) {
        ArrayList<Object> result = new ArrayList<>();
        for (Object o : objects) {
            if (f.accept(o)) {
                result.add(o);
            }
        }
        return result.toArray();
    }
}
