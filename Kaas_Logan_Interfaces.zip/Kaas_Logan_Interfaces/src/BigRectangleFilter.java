import java.awt.*;

public class BigRectangleFilter implements Filter {
    public boolean accept(Object x) {
        Rectangle rect = (Rectangle)x;
        return 2 * (rect.getWidth() + rect.getHeight()) > 10;
    }
}