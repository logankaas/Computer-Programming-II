import java.awt.*;
import java.text.DecimalFormat;
import javax.swing.*;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

public class PizzaGUIFrame extends JFrame {

    private static final int FRAME_WIDTH = 500;
    private static final int FRAME_HEIGHT = 500;
    private JRadioButton thinCrust, regularCrust, deepDishCrust;
    private JComboBox<String> sizes;
    private JCheckBox cheese, pepperoni, sausage, bacon, ham, pineapple;
    private JTextArea orderArea;
    private JButton order, clear, quit;
    private int toppingCounter = 0;
    private int toppingTotal;
    private double pizzaPrice;
    private double subTotal;
    private double tax = .07;
    private double taxBill;
    private String crust = "";
    private double totalBill;
    ButtonGroup bg = new ButtonGroup();

    public PizzaGUIFrame() {

        createMasterPanel();
        setSize(FRAME_WIDTH, FRAME_HEIGHT);
        setBackground(new Color(249, 195, 141));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("ORDER PIZZA");
        setVisible(true);
    }

    private void createMasterPanel() {
        JPanel crustTypePanel = crustRadioButton();
        JPanel pizzaSizePanel = pizzaSizeCombobox();
        JPanel toppingPanel = toppingCheckbox();
        JPanel receiptPanel = receiptTextArea();
        JPanel buttonPanel = controlButtons();

        JPanel panel = new JPanel();
        panel.add(crustTypePanel);
        panel.add(pizzaSizePanel);
        panel.add(toppingPanel);
        panel.add(receiptPanel);
        add(panel, BorderLayout.CENTER);
        JPanel panel2 = new JPanel();
        panel2.add(buttonPanel);
        add(panel2, BorderLayout.SOUTH);
    }

    private JPanel crustRadioButton() {
        thinCrust = new JRadioButton("THIN");
        thinCrust.addActionListener((e) -> {
            crust = "THIN";
        });
        regularCrust = new JRadioButton("REGULAR");
        regularCrust.addActionListener((e) -> {
            crust = "REGULAR";
        });
        deepDishCrust = new JRadioButton("DEEP-DISH");
        deepDishCrust.addActionListener((e) -> {
            crust = "DEEP-DISH";
        });

        bg.add(thinCrust);
        bg.add(regularCrust);
        bg.add(deepDishCrust);

        JPanel panel = new JPanel();
        panel.add(thinCrust);
        panel.add(regularCrust);
        panel.add(deepDishCrust);
        panel.setBorder(new TitledBorder(new EtchedBorder(), "CRUST STYLE"));
        return panel;
    }

    private JPanel pizzaSizeCombobox() {
        sizes = new JComboBox();
        String[] pizzaSizes = {"---SELECT---", "SMALL", "MEDIUM", "LARGE", "SUPER"};
        for (String pizzaSize : pizzaSizes) {
            sizes.addItem(pizzaSize);
        }
        sizes.addActionListener((e) -> {
            String choice = (String) sizes.getSelectedItem();
            if (choice.equalsIgnoreCase("SMALL")) {
                pizzaPrice = 8.00;
            }
            if (choice.equalsIgnoreCase("MEDIUM")) {
                pizzaPrice = 12.00;
            }
            if (choice.equalsIgnoreCase("LARGE")) {
                pizzaPrice = 16.00;
            }
            if (choice.equalsIgnoreCase("SUPER")) {
                pizzaPrice = 20.00;
            }
        });

        JPanel panel = new JPanel();
        panel.setBorder(new TitledBorder(new EtchedBorder(), "SIZES"));
        panel.add(sizes);
        return panel;
    }

    private JPanel toppingCheckbox() {
        cheese = new JCheckBox("CHEESE");
        cheese.addActionListener((e) -> {
            if (cheese.isSelected()) {
                toppingCounter++;
                toppingTotal = toppingCounter;
            } else {
                toppingCounter--;
                toppingTotal = toppingCounter;
            }
        });
        pepperoni = new JCheckBox("PEPPERONI");
        pepperoni.addActionListener((e) -> {
            if (pepperoni.isSelected()) {
                toppingCounter++;
                toppingTotal = toppingCounter;
            } else {
                toppingCounter--;
                toppingTotal = toppingCounter;
            }
        });

        sausage = new JCheckBox("SAUSAGE");
        sausage.addActionListener((e) -> {
            if (sausage.isSelected()) {
                toppingCounter++;
                toppingTotal = toppingCounter;
            } else {
                toppingCounter--;
                toppingTotal = toppingCounter;
            }
        });

        bacon = new JCheckBox("BACON");
        bacon.addActionListener((e) -> {
            if (bacon.isSelected()) {
                toppingCounter++;
                toppingTotal = toppingCounter;
            } else {
                toppingCounter--;
                toppingTotal = toppingCounter;
            }
        });

        ham = new JCheckBox("HAM");
        ham.addActionListener((e) -> {
            if (ham.isSelected()) {
                toppingCounter++;
                toppingTotal = toppingCounter;
            } else {
                toppingCounter--;
                toppingTotal = toppingCounter;
            }
        });

        pineapple = new JCheckBox("PINEAPPLE");
        pineapple.addActionListener((e) -> {
            if (pineapple.isSelected()) {
                toppingCounter++;
                toppingTotal = toppingCounter;
            } else {
                toppingCounter--;
                toppingTotal = toppingCounter;
            }
        });

        JPanel panel = new JPanel();
        panel.add(cheese);
        panel.add(pepperoni);
        panel.add(sausage);
        panel.add(bacon);
        panel.add(ham);
        panel.add(pineapple);
        panel.setBorder(new TitledBorder(new EtchedBorder(), "TOPPINGS"));

        return panel;
    }

    private JPanel receiptTextArea() {
        orderArea = new JTextArea(20, 40);
        orderArea.setEditable(false);
        JPanel panel = new JPanel();
        panel.add(orderArea);
        return panel;
    }

    private JPanel controlButtons() {
        order = new JButton("ORDER");
        order.addActionListener((e) -> {
            orderTotalPrintout();
        });

        clear = new JButton("CLEAR");
        clear.addActionListener((e) -> {
            clearTotalPrintOut();
        });

        quit = new JButton("QUIT");
        quit.addActionListener((e) -> {
            JOptionPane.showMessageDialog(quit, "ARE YOU SURE YOU WANT TO LEAVE YOUR ORDER?");
            System.exit(0);
        });

        JPanel panel = new JPanel();
        panel.add(order);
        panel.add(clear);
        panel.add(quit);

        return panel;
    }

    private void orderTotalPrintout() {
        DecimalFormat f = new DecimalFormat("0.00");
        String sTotal = "SUBTOTAL: ";
        orderArea.append("===========================\n");
        orderArea.append("CRUST STYLE: " + crust + "\n");
        orderArea.append("TOPPING TOTAL: " + f.format(toppingTotal) + "\n");
        orderArea.append("PIZZA PRICE " + f.format(pizzaPrice) + "\n");
        orderArea.append("\n");
        orderArea.append("\n");
        orderArea.append("\n");
        orderArea.append("\n");
        totalAmt();
        orderArea.append("SUBTOTAL: " + f.format(subTotal) + "\n");
        totalTax();
        orderArea.append(sTotal + f.format(taxBill) + "\n");
        orderArea.append("----------------------------------------------\n");
        totalBill();
        orderArea.append("TOTAL: " + f.format(totalBill));
    }

    private void clearTotalPrintOut(){
        orderArea.setText("");
        bg.clearSelection();
        cheese.setSelected(false);
        pepperoni.setSelected(false);
        sausage.setSelected(false);
        bacon.setSelected(false);
        ham.setSelected(false);
        pineapple.setSelected(false);
        sizes.setSelectedItem("---SELECT---");
    }

    private void totalAmt(){
        subTotal = (toppingTotal + pizzaPrice);
    }
    private void totalTax(){
        taxBill = (this.subTotal * .07);
    }
    private void totalBill(){
        totalBill = subTotal + taxBill;
    }

}