import javax.swing.*;
import java.awt.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class RandProductMaker extends JFrame {

    private static final int FRAME_WIDTH = 600;
    private static final int FRAME_HEIGHT = 500;
    JLabel nameLabel, descriptionLabel, IdLabel;
    JTextField nameTextField, descriptionTextField, IdTextField;
    JTextArea fileTextArea;
    JButton addProduct, displayProduct, clearProduct, quit;
    ButtonGroup bg = new ButtonGroup();

    public RandProductMaker() {

        createMasterPanel();
        setSize(FRAME_WIDTH, FRAME_HEIGHT);
        setBackground(new Color(249, 195, 141));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("PRODUCT MAKER");
        setVisible(true);
    }

    private void createMasterPanel() {
        JPanel enterProductPanel = inputProductPanel();
        JPanel productListArea = showProductListArea();
        JPanel buttonPanel = controlButtons();

        JPanel panel = new JPanel();
        panel.add(enterProductPanel);
        panel.add(productListArea);
        add(panel, BorderLayout.CENTER);
        JPanel panel2 = new JPanel();
        panel2.add(buttonPanel);
        add(panel2, BorderLayout.SOUTH);
    }

    private JPanel inputProductPanel() {

        JPanel panel = new JPanel();

        nameLabel = new JLabel();
        nameLabel.setText("NAME: ");
        nameLabel.setFont(new Font("Verdana", Font.PLAIN, 16));
        nameTextField = new JTextField();
        nameTextField.setPreferredSize(new Dimension(100, 20));
        descriptionLabel = new JLabel();
        descriptionLabel.setText("DESCRIPTION: ");
        descriptionLabel.setFont(new Font("Verdana", Font.PLAIN, 16));
        descriptionTextField = new JTextField();
        descriptionTextField.setPreferredSize(new Dimension(100, 20));
        IdLabel = new JLabel();
        IdLabel.setText("ID: ");
        IdLabel.setFont(new Font("Verdana", Font.PLAIN, 16));
        IdTextField = new JTextField();
        IdTextField.setPreferredSize(new Dimension(100, 20));

        panel.add(nameLabel);
        panel.add(nameTextField);
        panel.add(descriptionLabel);
        panel.add(descriptionTextField);
        panel.add(IdLabel);
        panel.add(IdTextField);

        return panel;
    }

    private JPanel controlButtons() {
        displayProduct = new JButton("DISPLAY PRODUCT");
        displayProduct.addActionListener((e) -> {
            enteredProductPrintout();
        });

        clearProduct = new JButton("CLEAR");
        clearProduct.addActionListener((e) -> {
            clearProductPrintOut();
        });

        addProduct = new JButton("ADD TO FILE");
        addProduct.addActionListener((e) -> {
            JOptionPane.showMessageDialog(addProduct, "ARE YOU SURE YOU WANT TO APPEND TO FILE?");
            appendToFile();
        });

        quit = new JButton("QUIT");
        quit.addActionListener((e) -> {
            JOptionPane.showMessageDialog(quit, "ARE YOU SURE YOU WANT TO LEAVE?");
            System.exit(0);
        });

        JPanel panel = new JPanel();
        panel.add(displayProduct);
        panel.add(clearProduct);
        panel.add(addProduct);
        panel.add(quit);

        return panel;
    }

    private JPanel showProductListArea() {
        fileTextArea = new JTextArea(20, 40);
        fileTextArea.setEditable(false);

        JPanel panel = new JPanel();
        panel.add(fileTextArea);

        return panel;
    }

    private void enteredProductPrintout() {
        String name, description, Id;

        name = nameTextField.getText().toString();
        description = descriptionTextField.getText().toString();
        Id = IdTextField.getText().toString();

        fileTextArea.append("NAME: " + name + "\n");
        fileTextArea.append("DESCRIPTION: " + description + "\n");
        fileTextArea.append("ID: " + Id + "\n");
        fileTextArea.append("===================================");
    }

    private void clearProductPrintOut(){
        fileTextArea.setText("");
        bg.clearSelection();
    }

    public void appendToFile() {
        PrintWriter fileWriter = null;

        String filePath = "C://Users/lckaa/IdeaProjects/Kaas_Logan_Ass02/src/products.txt";
        String appendingProductText = "\n" + fileTextArea.getText() + "\n";

        try{
            fileWriter = new PrintWriter(new BufferedWriter(new FileWriter(filePath, true)));
            fileWriter.write(appendingProductText);
            JOptionPane.showMessageDialog(addProduct, "APPENDED TO FILE SUCCESSFULLY.");
        }catch (IOException e) {
            e.printStackTrace();
        }finally {
            if(fileWriter != null){
                fileWriter.close();
            }
        }
    }

    public static void main(String[] args) {
        JFrame frame = new RandProductMaker();
    }
}
