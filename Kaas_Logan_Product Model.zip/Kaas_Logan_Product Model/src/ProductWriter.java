import javax.swing.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class ProductWriter {
    public static void main(String[] args) {
        ArrayList<String> personData = new ArrayList<>();

        Scanner input = new Scanner(System.in);
        String fileName = SafeInput.getNonZeroLenString(input, "Enter the name of the record to save the information to: ");

        boolean done = false;
        while (!done) {
            String id = SafeInput.getNonZeroLenString(input, "Enter the ID: ");
            String firstName = SafeInput.getNonZeroLenString(input, "Enter the Name: ");
            String description = SafeInput.getNonZeroLenString(input, "Enter the description: ");
            int cost = SafeInput.getInt(input, "Enter the cost: ");

            personData.add(id + "," + firstName + "," + description + "," + cost);

            String cont = SafeInput.getNonZeroLenString(input, "Would you say you are finished entering information? (yes/no) ");
            if (cont.equalsIgnoreCase("yes")) {
                done = true;
            }

            JFileChooser chooser = new JFileChooser();
            File file = chooser.getSelectedFile();
        }
    }
}