public class TicTacToeRunner {
    public static void main(String[] args) throws Exception {
        new TicTacToeFrame();
    }
}