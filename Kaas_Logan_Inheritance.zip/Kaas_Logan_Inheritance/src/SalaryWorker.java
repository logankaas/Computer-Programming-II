public class SalaryWorker extends Worker {
    private double annualSalary;

    public SalaryWorker(String ID, String firstName, String lastName, String title, int YOB, double annualSalary){
        super(ID, firstName, lastName, title, YOB, (annualSalary / 52) / 40);
        this.annualSalary = annualSalary;
    }

    public double calculateWeeklyPay(double hoursWorked){
        double weeklyPay = annualSalary/52;
        return weeklyPay;
    }

    public void displayWeeklyPay(){
        double weeklyPay = calculateWeeklyPay(0);
        System.out.println("This is a fraction of the yearly salary: "+weeklyPay);
    }
}
