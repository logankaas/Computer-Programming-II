import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.PrintWriter;

public class ProductGenerator {

    public static void main(String[] args) throws FileNotFoundException {

        Scanner in = new Scanner(System.in);
        ArrayList<Product> products = new ArrayList<>();

        int index = 1;

        while (SafeInput.getYNConfirm(in, "Create new product?")) {

            System.out.println("Name: ");
            String name = in.nextLine();
            System.out.println("\nDescription: ");
            String description = in.nextLine();
            System.out.println("\nID: ");
            String id = in.nextLine();

            products.add(new Product(name, description, id));

            index++;
        }

        System.out.println("\nEnter output file name: ");
        String outputFileName = in.nextLine();
        PrintWriter out = new PrintWriter(outputFileName);

        for (Product product : products) {
            out.println(product.toCSVDataRecord());
        }

        out.close();
    }
}