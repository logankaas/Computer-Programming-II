import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class RockPaperScissorsFrame extends JFrame {

    public static final int WIDTH = 800;
    public static final int HEIGHT = 600;

    Random rand = new Random();
    int playerWins = 0;
    int computerWins = 0;
    int ties = 0;

    JPanel outerPanel;
    JPanel topPanel;
    JPanel midPanel;
    JPanel botPanel;

    JLabel titleLabel;

    JButton quitButton;
    JButton rock;
    JButton paper;
    JButton scissors;

    JTextField nameField;

    JLabel PlayerWinsLabel;
    JLabel ComputerWinsLabel;
    JLabel TiesLabel;

    JTextArea rpsArea;

    JScrollPane rpsScroller;

    public RockPaperScissorsFrame() throws HeadlessException {

        outerPanel = new JPanel();
        topPanel = new JPanel();
        midPanel = new JPanel();
        botPanel = new JPanel();

        titleLabel = new JLabel("");

        quitButton = new JButton("QUIT");

        rock = new JButton("ROCK");
        paper = new JButton("PAPER");
        scissors = new JButton("SCISSORS");

        PlayerWinsLabel = new JLabel("PLAYER WINS: 0");
        ComputerWinsLabel = new JLabel("COMPUTER WINS: 0");
        TiesLabel = new JLabel("TIES: 0");

        nameField = new JTextField();
        nameField.setColumns(15);

        rpsArea = new JTextArea(10, 50);
        rpsArea.setEditable(false);

        rpsScroller = new JScrollPane(rpsArea);

        rock.addActionListener(new ClickListenerRock());
        paper.addActionListener(new ClickListenerPaper());
        scissors.addActionListener(new ClickListenerScissors());
        quitButton.addActionListener((ActionEvent actionEvent) -> System.exit(0));

        setSize(WIDTH, HEIGHT);
        setTitle("ROCK PAPER SCISSORS GAME");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        outerPanel.setLayout(new BoxLayout(outerPanel, BoxLayout.PAGE_AXIS));
        add(outerPanel);

        outerPanel.add(topPanel);
        topPanel.add(PlayerWinsLabel);
        topPanel.add(ComputerWinsLabel);
        topPanel.add(TiesLabel);

        outerPanel.add(midPanel);
        midPanel.add(rpsScroller);

        outerPanel.add(botPanel);
        botPanel.add(rock);
        botPanel.add(paper);
        botPanel.add(scissors);
        botPanel.add(quitButton);

        setVisible(true);
    }

    public class ClickListenerRock implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            rpsArea.append("YOUR CHOICE: ROCK\n");
            computerLogic(0);
        }
    }

    public class ClickListenerPaper implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            rpsArea.append("YOUR CHOICE: PAPER\n");
            computerLogic(1);

        }
    }

    public class ClickListenerScissors implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            rpsArea.append("YOUR CHOICE: SCISSORS\n");
            computerLogic(2);
        }
    }

    // logic: 0 = rock, 1 = paper, 2 = scissors
    private void computerLogic(int playerMove) {
        int computerMove = rand.nextInt(3);

        if (computerMove == playerMove){
            if (computerMove == 0){
                rpsArea.append("COMPUTER CHOICE: ROCK\n IT'S A TIE\n");
            }
            else if (computerMove == 1){
                rpsArea.append("COMPUTER CHOICE: PAPER\n IT'S A TIE\n");
            }
            else{
                rpsArea.append("COMPUTER CHOICE: SCISSORS\n IT'S A TIE\n");
            }
            ties++;
            TiesLabel.setText("TIES: " + ties);
        }
        else if (computerMove == 0 && playerMove == 1){
            rpsArea.append("COMPUTER CHOICE: ROCK\nYOU LOST\n");
            playerWins++;
        }
        else if (computerMove == 0 && playerMove == 2){
            rpsArea.append("COMPUTER CHOICE: ROCK\nYOU LOST\n");
            computerWins++;
        }
        else if (computerMove == 1 && playerMove == 0){
            rpsArea.append("COMPUTER CHOICE: PAPER\nYOU LOST\n");
            computerWins++;
        }
        else if (computerMove == 1 && playerMove == 2){
            rpsArea.append("COMPUTER CHOICE: PAPER\nYOU WIN\n");
            playerWins++;
        }
        else if (computerMove == 2 && playerMove == 0){
            rpsArea.append("COMPUTER CHOICE: SCISSORS\nYOU WIN\n");
            playerWins++;
        }
        else if (computerMove == 2 && playerMove == 1){
            rpsArea.append("COMPUTER CHOICE: SCISSORS\nYOU LOST\n");
            computerWins++;
        }

        PlayerWinsLabel.setText("PLAYER WINS: " + playerWins);
        ComputerWinsLabel.setText("COMPUTER WINS: " + computerWins);
    }
}