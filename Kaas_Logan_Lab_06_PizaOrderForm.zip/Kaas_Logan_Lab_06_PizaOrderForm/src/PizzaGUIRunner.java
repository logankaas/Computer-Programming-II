import javax.swing.JFrame;

public class PizzaGUIRunner {
    public static void main(String[] args) {

        JFrame frame = new PizzaGUIFrame();
    }

}
