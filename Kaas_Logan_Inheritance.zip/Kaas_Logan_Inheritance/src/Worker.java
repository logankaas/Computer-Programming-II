public class Worker extends Person {
    private double hourlyPayRate;

    public Worker(String ID, String firstName, String lastName, String title, int YOB, double hourlyPayRate) {
        super(ID, firstName, lastName, title, YOB);
        this.hourlyPayRate = hourlyPayRate;
    }

    public double calculateWeeklyPay(double hoursWorked) {
        double totalPay;

        if (hoursWorked <= 40) {
            totalPay = hoursWorked * hourlyPayRate;
        }

        else {
            double overtimeHour = hoursWorked - 40;
            double overtimePay = overtimeHour * (hourlyPayRate * 1.5);
            double regularPay = 40 * hourlyPayRate;
            totalPay = overtimePay + regularPay;
        }
        return totalPay;
    }

    public String displayWeeklyPay(double hoursWorked) {
        double totalPay;
        double regularHours;
        double overtimeHours;
        double regularPay;
        double overtimePay;

        if (hoursWorked <= 40) {
            totalPay = hoursWorked * hourlyPayRate;
            regularHours = hoursWorked;
            overtimeHours = 0;
            regularPay = totalPay;
            overtimePay = 0;
        }

        else {
            overtimeHours = hoursWorked - 40;
            double overtimePayment = overtimeHours * (hourlyPayRate * 1.5);
            double regularPayment = 40 * hourlyPayRate;
            totalPay = overtimePayment + regularPayment;
            regularHours = 40;
            regularPay = regularHours * hourlyPayRate;
            overtimePay = overtimeHours * (hourlyPayRate * 1.5);
        }

        return "Regular Hours: " + regularHours + " hours, Regular Pay: $" + regularPay
                + "\nOvertime Hours: " + overtimeHours + " hours, Overtime Pay: $" + overtimePay
                + "\nTotal Pay: $" + totalPay;
    }
}
