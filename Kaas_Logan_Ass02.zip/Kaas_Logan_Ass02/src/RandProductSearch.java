import javax.annotation.processing.Filer;
import javax.swing.*;
import javax.swing.filechooser.FileSystemView;
import java.awt.*;
import java.io.*;
import java.lang.reflect.WildcardType;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Scanner;
import java.util.stream.Stream;

public class RandProductSearch extends JFrame {

    private static final int FRAME_WIDTH = 1000;
    private static final int FRAME_HEIGHT = 600;
    JLabel nameLabel, descriptionLabel, IdLabel, wildcardSearchLabel;
    JTextField nameTextField, descriptionTextField, IdTextField, wildcardSearchTextField;
    JTextArea fileTextArea;
    JButton addProduct, displayProduct, clearProduct, searchProduct, quit;
    ButtonGroup bg = new ButtonGroup();

    public RandProductSearch() {

        createMasterPanel();
        setSize(FRAME_WIDTH, FRAME_HEIGHT);
        setBackground(new Color(249, 195, 141));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("PRODUCT MAKER");
        setVisible(true);
    }

    private void createMasterPanel() {
        JPanel enterProductPanel = inputProductPanel();
        JPanel productListArea = showProductListArea();
        JPanel buttonPanel = controlButtons();

        JPanel panel = new JPanel();
        panel.add(enterProductPanel);
        panel.add(productListArea);
        add(panel, BorderLayout.CENTER);
        JPanel panel2 = new JPanel();
        panel2.add(buttonPanel);
        add(panel2, BorderLayout.SOUTH);
    }

    private JPanel inputProductPanel() {

        JPanel panel = new JPanel();

        nameLabel = new JLabel();
        nameLabel.setText("NAME: ");
        nameLabel.setFont(new Font("Verdana", Font.PLAIN, 16));
        nameTextField = new JTextField();
        nameTextField.setPreferredSize(new Dimension(100, 20));
        descriptionLabel = new JLabel();
        descriptionLabel.setText("DESCRIPTION: ");
        descriptionLabel.setFont(new Font("Verdana", Font.PLAIN, 16));
        descriptionTextField = new JTextField();
        descriptionTextField.setPreferredSize(new Dimension(100, 20));
        IdLabel = new JLabel();
        IdLabel.setText("ID: ");
        IdLabel.setFont(new Font("Verdana", Font.PLAIN, 16));
        IdTextField = new JTextField();
        IdTextField.setPreferredSize(new Dimension(100, 20));
        wildcardSearchLabel = new JLabel();
        wildcardSearchLabel.setText("SEARCH PARTIAL PRODUCT MATCH: ");
        wildcardSearchLabel.setFont(new Font("Verdana", Font.PLAIN, 16));
        wildcardSearchTextField = new JTextField();
        wildcardSearchTextField.setPreferredSize(new Dimension(100, 20));

        panel.add(nameLabel);
        panel.add(nameTextField);
        panel.add(descriptionLabel);
        panel.add(descriptionTextField);
        panel.add(IdLabel);
        panel.add(IdTextField);
        panel.add(wildcardSearchLabel);
        panel.add(wildcardSearchTextField);

        return panel;
    }

    private JPanel controlButtons() {
        displayProduct = new JButton("DISPLAY PRODUCT");
        displayProduct.addActionListener((e) -> {
            enteredProductPrintout();
        });

        clearProduct = new JButton("CLEAR");
        clearProduct.addActionListener((e) -> {
            clearProductPrintOut();
        });

        addProduct = new JButton("ADD TO FILE");
        addProduct.addActionListener((e) -> {
            JOptionPane.showMessageDialog(addProduct, "ARE YOU SURE YOU WANT TO APPEND TO FILE?");
            appendToFile();
        });

        searchProduct = new JButton("SEARCH PARTIAL PRODUCT MATCH");
        searchProduct.addActionListener((e) -> {
            readFileForWildcardMatch();
        });

        quit = new JButton("QUIT");
        quit.addActionListener((e) -> {
            JOptionPane.showMessageDialog(quit, "ARE YOU SURE YOU WANT TO LEAVE?");
            System.exit(0);
        });

        JPanel panel = new JPanel();
        panel.add(displayProduct);
        panel.add(clearProduct);
        panel.add(addProduct);
        panel.add(searchProduct);
        panel.add(quit);

        return panel;
    }

    private JPanel showProductListArea() {
        fileTextArea = new JTextArea(30, 60);
        fileTextArea.setEditable(false);

        JPanel panel = new JPanel();
        panel.add(fileTextArea);

        return panel;
    }

    private void enteredProductPrintout() {
        String name, description, Id;

        name = nameTextField.getText().toString();
        description = descriptionTextField.getText().toString();
        Id = IdTextField.getText().toString();

        fileTextArea.append("NAME: " + name + "\n");
        fileTextArea.append("DESCRIPTION: " + description + "\n");
        fileTextArea.append("ID: " + Id + "\n");
        fileTextArea.append("===================================");
    }

    private void clearProductPrintOut(){
        fileTextArea.setText("");
        bg.clearSelection();
    }

    public void appendToFile() {
        PrintWriter fileWriter = null;

        String filePath = "C://Users/lckaa/IdeaProjects/Kaas_Logan_Ass02/src/products.txt";
        String appendingProductText = "\n" + fileTextArea.getText() + "\n";

        try{
            fileWriter = new PrintWriter(new BufferedWriter(new FileWriter(filePath, true)));
            fileWriter.write(appendingProductText);
            JOptionPane.showMessageDialog(addProduct, "APPENDED TO FILE SUCCESSFULLY.");
        }catch (IOException e) {
            e.printStackTrace();
        }finally {
            if(fileWriter != null){
                fileWriter.close();
            }
        }
    }

    //public void findWildcardSearchMatch() {
        //final Collection<String> simpleStringCollection = new ArrayList<>();

        //String wildCardValue;

        //wildCardValue = wildcardSearchTextField.getText().toString();
        //fileTextArea.append("Partial Search: " + wildCardValue);

        //final Path dir = Paths.get("C://Users/lckaa/IdeaProjects/Kaas_Logan_Ass02/products.txt");

        //try{
            //Stream<Path> results = Files.find(dir,
                    //Integer.MAX_VALUE,
                    //(path, basicFileAttributes) -> path.toFile().getName().matches(wildCardValue)
            //);

            //results.forEach(p -> simpleStringCollection.add(p.toString()));
        //}catch (IOException e){
            //throw new UncheckedIOException(e);
        //}
    //}

    public void readFileForWildcardMatch() {

        try{
            String wildCardValue;
            wildCardValue = wildcardSearchTextField.getText().toString();
            fileTextArea.append("PARTIAL PRODUCT SEARCHED: " + wildCardValue + "\n");

            String filePath = "C://Users/lckaa/IdeaProjects/Kaas_Logan_Ass02/src/products.txt";
            File fileText = new File(filePath);

            Scanner scanner = new Scanner(fileText);
            fileTextArea.append(scanner.next());
            scanner.close();

            FileReader reader = new FileReader(filePath);
            fileTextArea.read(reader, filePath);


        }catch (IOException e){
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        JFrame frame = new RandProductSearch();
    }
}
