import java.awt.Font;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.*;
import javax.swing.filechooser.FileSystemView;

public class TagExtractor extends JFrame
{

    String inputFileName;
    String stopFileName;
    String inputFilePath;
    String stopFilePath;

    ArrayList<String> stop = new ArrayList<>();
    TreeMap<String, Integer> tags = new TreeMap<String, Integer>();

    JButton chooseFile = new JButton("CHOOSE FILE");
    JButton stopFile = new JButton("STOP FILE");
    JButton saveFile = new JButton("SAVE TO FILE");
    JLabel FileNameLabel = new JLabel();
    JLabel Label = new JLabel();
    JScrollPane panel3;

    JTextArea textarea = new JTextArea();

    public TagExtractor() {

        JFrame frame = new JFrame("FILE CHOOSER");
        frame.setSize(600, 600);

        textarea.setFont(new Font("Times New Roman", Font.PLAIN, 20));

        frame.setVisible(true);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.setLayout(null);

        chooseFile.setBounds(10, 10, 100, 30);
        stopFile.setBounds(10, 50, 100, 30);
        FileNameLabel.setBounds(130, 10, 200, 30);
        Label.setBounds(130, 50, 200, 30);
        saveFile.setBounds(10, 500, 100, 30);

        frame.add(chooseFile);
        frame.add(stopFile);
        frame.add(FileNameLabel);
        frame.add(Label);
        frame.add(saveFile);

        textarea.setBounds(10, 10, 300, 300);
        panel3 = new JScrollPane(textarea);
        panel3.setBounds(10, 100, 400, 400);
        frame.add(panel3);

        chooseFile.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                JFileChooser j = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());

                int r = j.showSaveDialog(null);

                if (r == JFileChooser.APPROVE_OPTION) {

                    inputFileName = j.getSelectedFile().getName();
                    inputFilePath = j.getSelectedFile().getAbsolutePath();
                    FileNameLabel.setText("FILE NAME: " + inputFileName);
                    textarea.setText("");
                    tags.clear();
                } else {
                    FileNameLabel.setText("FILE NOT CHOSEN");
                }
            }

        });

        stopFile.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                JFileChooser j = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());

                int r = j.showSaveDialog(null);

                if (r == JFileChooser.APPROVE_OPTION) {

                    stopFilePath = j.getSelectedFile().getAbsolutePath();
                    Label.setText("");
                    readStopFile();
                    Perform();
                } else {
                    Label.setText("FILE NOT CHOSEN");
                }
            }

        });

        saveFile.addActionListener(new ActionListener() {
                                       @Override
                                       public void actionPerformed(ActionEvent e) {

                                           try {
                                               FileWriter fw = new FileWriter("SampleOutput.txt");

                                               for (Map.Entry m : tags.entrySet()) {

                                                   fw.write((String.format("%-10s\t\t%d\n",m.getKey(), m.getValue())));
                                               }

                                               JOptionPane.showMessageDialog(Label, "FILE SAVED");

                                               fw.close();
                                           } catch (Exception ex) {
                                               System.out.println(ex);
                                           }

                                       }

                                   }
        );
    }

    public static void main(String[] args)
    {
        new TagExtractor();
    }

    public String removeNonCharacter(String word) {

        for (int i = 0; i < word.length(); i++) {
            char c = word.charAt(i);
            if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) {
                continue;
            } else {
                word = word.replace(c + "", " ");
            }
        }

        return word;
    }

    public void insert(String word) {
        if (word != null && !"".equals(word) && !"".equals(word)) {
            tags.put(word, 1);
        }
    }

    public void Perform() {

        try {
            FileInputStream fis = new FileInputStream(inputFilePath);
            Scanner sc = new Scanner(fis);
            while (sc.hasNextLine())
            {
                String line = sc.nextLine().toLowerCase();
                line = removeNonCharacter(line);
                String word[] = line.split("");
                for (int i = 0; i < word.length; i++) {
                    String current = word[i];

                    if (isAvailable(current, tags)) {

                    }
                    else if (!isStop(current)) {
                        insert(current);

                    }
                }
            }
            sc.close();
        } catch (IOException e) {
            e.printStackTrace();
        }


        for (Map.Entry m : tags.entrySet()) {

            textarea.append(String.format("%-10s\t\t%d\n",m.getKey(), m.getValue()));

        }

    }

    public void readStopFile()
    {

        try {
            FileInputStream fis = new FileInputStream(stopFilePath);
            Scanner sc = new Scanner(fis);
            while (sc.hasNextLine())
            {
                stop.add(sc.nextLine());
            }
            sc.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public boolean isStop(String word) {
        for (String s : stop) {
            if (s.equals(word)) {
                return true;
            }
        }

        return false;
    }

    public boolean isAvailable(String word, TreeMap<String, Integer> tags)
    {
        for (Map.Entry m : tags.entrySet()) {
            if (m.getKey().equals(word)) {
                int value = Integer.parseInt(m.getValue().toString()) + 1;
                m.setValue(value);

                return true;
            }
        }

        return false;
    }
}