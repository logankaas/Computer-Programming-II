import java.awt.*;
import java.util.ArrayList;

public interface Filter {
    boolean accept(Object x);
}