import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.*;

public class RecursiveLister extends JFrame implements ActionListener {

    private JButton fileChooserButton, quitButton;

    private JTextArea output;

    private JLabel currentDirectoryLabel;


    public RecursiveLister() {

        super("RECURSIVE FILE LISTER");

        JPanel btnPanel = new JPanel();
        fileChooserButton = new JButton("CHOOSE DIRECTORY");
        quitButton = new JButton("QUIT");
        btnPanel.add(fileChooserButton);
        btnPanel.add(quitButton);


        output = new JTextArea(10, 50);
        currentDirectoryLabel = new JLabel("CURRENT DIRECTORY:");

        add(btnPanel, BorderLayout.PAGE_START);
        add(new JScrollPane(output));
        add(currentDirectoryLabel, BorderLayout.PAGE_END);

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(700, 700);
        setVisible(true);

        fileChooserButton.addActionListener(this);

        quitButton.addActionListener(this);
    }


    public static void main(String[] args) {
        new RecursiveLister();
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(fileChooserButton)) {
            output.setText("");
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            int status = fileChooser.showOpenDialog(this);

            if (status == JFileChooser.APPROVE_OPTION) {
                File f = fileChooser.getSelectedFile();
                currentDirectoryLabel.setText("CURRENT DIRECTORY: " + f);
                listFiles(f);
            }

        } else if (e.getSource().equals(quitButton)) {
            System.exit(0);
        }

    }


    private void listFiles(File file) {
        if (file.isFile()) {

            output.append(file + "\n");

        } else {
            File files[] = file.listFiles();

            if (files != null) {
                for (File f : files) {
                    output.append(f + "\n");

                    if (f.isDirectory()) {
                        listFiles(f);

                    }

                }

            }

        }

    }


}